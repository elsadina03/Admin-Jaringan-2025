﻿**Analisa file http.cap**

1. ![ref1]Versi HTTP





   ![](Aspose.Words.8a7c7098-087f-41c4-a780-bbd4876d58fb.002.png)



1. Di kolom “Display Filter” ketik HTTP untuk menampilkan hanya paket HTTP
1. Klik pada salah satu paket HTTP
1. Buka bagian Hypertext Transfer Protocol
1. Tertera bahwa versi HTTP yang digunakan adalah HTTP/1.1 
1. ![](Aspose.Words.8a7c7098-087f-41c4-a780-bbd4876d58fb.003.png)IP Adrress Client dan Server

1. ![ref2]![ref2]
1. Lihat pada bagian source dan destination atau Internet Protocol
1. IP client adalah 145.254.160.237, sedangkah IP server adalah 216.239.59.99

![ref1]3. Waktu dari client mengirimkan HTTP request

![ref2]







1. Lihat pada bagian HTTP request GET /download.html pada kolom Time
1. Client (145.254.160.237) mengirimkan request pada 0.911310 detik
1. ![ref1]Waktu dari server mengirinmkan server dan durasinya

   ![ref2]![ref2]









1. Lihat pada bagian HTTP request GET /download.html pada kolom Time. Client  	 (145.254.160.237) mengirimkan request pada 0.911310 detik
1. Lihat pada bagian HTTP OK pada kolom Time. Server (216.239.59.99) 			  mengirimkan request pada 3.955688 detik
1. Durasi

`	  `3.955688−0.911310=3.044378 detik

**Analisis Type of Data Deliveries**

![](Aspose.Words.8a7c7098-087f-41c4-a780-bbd4876d58fb.005.png)

1. **Node to Node (Data Link Layer)**
- Komunikasi terjadi antar perangkat jaringan (misalnya switch, router) dalam satu segmen jaringan
- Menggunakan MAC Address untuk mengidentifikasi perangkat dalam jaringan lokal
1. **Host to Host (Network Layer)**
- Menghubungkan satu host ke host lain dalam jaringan yang lebih luas (misalnya, dari satu komputer ke komputer lain di internet)
- Menggunakan IP Address untuk menentukan alamat sumber dan tujuan
1. **Process to Process (Transport Layer)**
- Memastikan komunikasi terjadi antar aplikasi atau proses di perangkat sumber dan tujuan
- Menggunakan port number untuk menentukan aplikasi yang menerima data

**Kesimpulan:**

Komunikasi jaringan berlangsung secara bertahap dari **node ke node** (antar perangkat dalam jaringan), lalu antar **host ke host** (antar komputer dalam internet), hingga akhirnya sampai pada **proses ke proses** (antar aplikasi atau layanan dalam perangkat)


**TAHAPAN TCP**

1. **Establishment – Three-Way Handshake**
   **
   `	`Memastikan kedua perangkat siap berkomunikasi sebelum mengirim data

1. SYN (Synchronize): client mengirimkan permintaan koneksi ke server
1. SYN-ACK (Synchronize-Acknowledge): server merespons dengan persetujuan
1. ACK (Acknowledge): client mengonfirmasi sehingga koneksi terbentuk
1. **Data Transfer**

   `	`Setelah koneksi terjalin, data dapat dikirim antara client dan server

- Menggunakan TCP segments dengan nomor urut (sequence number) untuk memastikan urutan data benar
- Jika ada paket hilang, TCP akan meminta pengiriman ulang
- TCP menggunakan mekanisme flow control dan congestion control untuk menghindari kelebihan beban jaringan
1. **Termination – Four-Way Handshake**
   **
   `	`Proses ini mengakhiri koneksi TCP dengan aman setelah data selesai dikirim

1. FIN (Finish): Salah satu pihak (client/server) mengirim permintaan untuk mengakhiri koneksi
1. ACK: Pihak lain mengakui permintaan tersebut
1. FIN: Pihak lain juga mengirim permintaan untuk menutup koneksi
1. ACK: Koneksi benar-benar ditutup setelah pihak pertama mengonfirmasi

[ref1]: Aspose.Words.8a7c7098-087f-41c4-a780-bbd4876d58fb.001.png
[ref2]: Aspose.Words.8a7c7098-087f-41c4-a780-bbd4876d58fb.004.png
